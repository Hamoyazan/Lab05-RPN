# Lab06_ReversePolishNotation

This is a Scaffold for the [Info2](https://home.htw-berlin.de/~kleinen/info2) Lab
"Reverse Polish Notation"
